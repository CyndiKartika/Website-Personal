<?php 
session_start();
include "koneksi.php";

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $_SESSION['username'] = $username;
        header("Location: dashboard.php");
    } else {
        $error = "Username atau password salah!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Login CentralHome</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }
    .card {
      border-radius: 15px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.15);
      padding: 30px;
    }
    .logo {
      width: 80px;
      height: auto;
      margin-bottom: 15px;
    }
  </style>
</head>
<body>
  <div class="card text-center">
    <img src="images/logo.jpg" class="logo mx-auto d-block" alt="Logo NusantaraRasa">
    <h4 class="mb-3">NusantaraRasa Login</h4>

    <?php if (isset($error)): ?>
      <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST" class="text-start">
      <div class="mb-3">
        <label for="username" class="form-label">Username</label>
        <input type="text" name="username" class="form-control" required>
      </div>
      <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" name="password" class="form-control" required>
      </div>
      <button type="submit" name="login" class="btn btn-primary w-100">Masuk</button>
    </form>

    <p class="mt-3 mb-0 small">Belum punya akun? <a href="register.php">Daftar di sini</a></p>
    <p class="mt-3 mb-0 small">Kembali ke Landing Page <a href="index.php">Home</a></p>
  </div>
</body>
</html>
