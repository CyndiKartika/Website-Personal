<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>PT. Nusantara Rasa</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  background-color: #e0e0e0;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
}


    .header-brand {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 20px 40px;
      background-color: #ccc; /* Warna abu-abu */
      position: relative;
    }

    .logo-img {
      height: 70px;
    }

    .company-name {
      position: absolute;
      left: 50%;
      transform: translateX(-50%);
      font-size: 2rem;
      font-weight: bold;
      color: #333;
      text-shadow: 1px 1px #fff;
      margin: 0;
    }

    .nav-custom {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-color: rgba(255, 255, 255, 0.95);
      border-bottom: 2px solid #000;
      padding: 0 20px;
    }

    .nav-left, .nav-center {
      display: flex;
      align-items: center;
    }

    .nav-center {
      margin: 0 auto;
    }

    .nav-left a,
    .nav-center a {
      padding: 10px 15px;
      color: #000;
      text-decoration: none;
      font-weight: bold;
      border-right: 1px solid #000;
    }

    .nav-left a:last-child,
    .nav-center a:last-child {
      border-right: none;
    }

    .nav-left a:hover,
    .nav-center a:hover {
      background-color: #ffc107;
      color: #000;
    }

    .sidebar {
      background-color: rgba(255, 255, 255, 0.9);
      padding: 20px;
      height: 100%;
      border-right: 1px solid #ddd;
    }

    .main-content {
      background-color: rgba(255, 255, 255, 0.9);
      padding: 20px;
      min-height: 400px;
    }

    footer {
      background-color: #e0e0e0; /* Warna abu-abu muda */
      text-align: right;
      padding: 10px 30px;
      font-size: 0.9rem;
      color: #555;
    }

    @media (max-width: 768px) {
      .nav-custom a {
        flex: 1 0 50%;
        text-align: center;
      }

      .header-brand {
        flex-direction: column;
        align-items: center;
      }

      .company-name {
        position: static;
        transform: none;
        margin-top: 10px;
        text-align: center;
      }
    }

    .main-section {
  background-color: #40e0d0; /* Biru toska */
  padding-top: 20px;
  padding-bottom: 20px;
}

  </style>
</head>
<body>

  <!-- Header -->
  <div class="header-brand">
    <img src="images/logo.jpg" alt="Logo" class="logo-img">
    <div class="company-name">Nusantara Rasa</div>
  </div>

  <!-- Navigation -->
  <div class="nav-custom">
    <div class="nav-left">
      <a href="index.php?page=home">Home</a>
    </div>
    <div class="nav-center">
      <a href="index.php?page=profile">Profile</a>
      <a href="index.php?page=visi">Visi dan Misi</a>
      <a href="index.php?page=produk">Produk Kami</a>
      <a href="index.php?page=kontak">Kontak</a>
      <a href="index.php?page=about"><u>About us</u></a>
    </div>
  </div>

  <!-- Main Section -->
  <div class="container-fluid">
    <div class="row">
      <!-- Sidebar -->
      <div class="col-md-3 sidebar">
        <div class="dropdown mb-3">
          <h6 class="dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" style="cursor:pointer">
            Artikel
          </h6>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="index.php?page=artikel&kategori=Lainnya">Jejak Langkah Nusantara Rasa dalam Program Tanggung Jawab Sosial Perusahaan</a></li>
            <li><a class="dropdown-item" href="index.php?page=artikel&kategori=Informasi">Nusantara Rasa Raih Penghargaan "Produk Makanan Terbaik 2024"</a></li>
            <li><a class="dropdown-item" href="index.php?page=artikel&kategori=Konsep">Konsep "Farm-to-Table" PT. Nusantara Rasa: Menjamin Kesegaran Bahan Baku</a></li>
            <li><a class="dropdown-item" href="index.php?page=artikel&kategori=Teknologi">Memadukan Rempah Lokal dalam Produk Unggulan Nusantara Rasa</a></li>
          </ul>
        </div>

        <a href="?page=event-galeri" class="text-decoration-none text-dark">
  <h6>Event Galeri</h6>
</a>
<a href="?page=fotoklien" class="text-decoration-none text-dark">
  <h6>Foto Klien</h6>
</a>

        <h6>Login</h6>
        <ul class="list-unstyled ms-3">
          <li><a href="login.php">Sign in</a></li>
          <li><a href="register.php">Sign up</a></li>
        </ul>
      </div>
<!-- Main Content -->
<div class="col-md-9 main-content">
  <?php
    $page = isset($_GET['page']) ? $_GET['page'] : 'home';

    // Tambahkan nama file tanpa .php ke daftar halaman yang diizinkan
    $allowed_pages = ['home', 'profile', 'visi', 'produk', 'kontak', 'about', 'artikel', 'event-galeri', 'fotoklien'];

    if (in_array($page, $allowed_pages) && file_exists("pages/$page.php")) {
      include "pages/$page.php";
    } else {
      echo "<h2>Selamat Datang di NusantaraRasa</h2>
      <p>Silakan pilih menu di atas untuk melihat profil perusahaan, produk, atau informasi lainnya.</p>";
    }
  ?>
</div>


  <!-- Footer -->
  <footer>
    Design by : Cyndi Kartika Kumala Dewi
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
