<?php
include "koneksi.php";

if (isset($_POST['register'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Cek apakah username sudah ada
    $cek = "SELECT * FROM users WHERE username = '$username'";
    $result = $conn->query($cek);

    if ($result->num_rows > 0) {
        $error = "Username sudah digunakan!";
    } else {
        // Simpan user baru
        $sql = "INSERT INTO users (username, password) VALUES ('$username', '$password')";
        if ($conn->query($sql)) {
            $success = "Pendaftaran berhasil! Silakan login.";
        } else {
            $error = "Gagal mendaftar!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Register - NusantaraRasa</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f0f2f5;
    }
    .register-container {
      margin-top: 80px;
    }
    .card {
      border-radius: 15px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    .logo {
      width: 70px;
      margin-bottom: 15px;
    }
  </style>
</head>
<body>
  <div class="container register-container">
    <div class="row justify-content-center">
      <div class="col-md-4">
        <div class="card p-4">
          <div class="text-center">
            <img src="images/logo.jpg" class="logo" alt="Logo NusantaraRasa">
            <h3 class="mb-3">Daftar Akun</h3>
          </div>
          <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
          <?php if (isset($success)) echo "<div class='alert alert-success'>$success</div>"; ?>
          <form method="POST">
            <div class="mb-3">
              <label for="username" class="form-label">Username</label>
              <input type="text" name="username" class="form-control" required>
            </div>
            <div class="mb-3">
              <label for="password" class="form-label">Password</label>
              <input type="password" name="password" class="form-control" required>
            </div>
            <button type="submit" name="register" class="btn btn-success w-100">Daftar</button>
          </form>
          <div class="mt-3 text-center">
            <small>Sudah punya akun? <a href="login.php">Login di sini</a></small>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
