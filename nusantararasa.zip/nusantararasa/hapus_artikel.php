<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Ambil nama gambar terlebih dahulu
    $query = mysqli_query($koneksi, "SELECT gambar FROM artikel WHERE id = '$id'");
    $data = mysqli_fetch_assoc($query);

    // Hapus file gambar jika ada
    if (!empty($data['gambar']) && file_exists("gambar_artikel/" . $data['gambar'])) {
        unlink("gambar_artikel/" . $data['gambar']);
    }

    // Hapus data dari tabel artikel
    $hapus = mysqli_query($koneksi, "DELETE FROM artikel WHERE id = '$id'");

    if ($hapus) {
        echo "<script>alert('Artikel berhasil dihapus.'); window.location='dashboard.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus artikel.'); window.location='dashboard.php';</script>";
    }
} else {
    echo "<script>alert('ID tidak ditemukan.'); window.location='dashboard.php';</script>";
}
?>
