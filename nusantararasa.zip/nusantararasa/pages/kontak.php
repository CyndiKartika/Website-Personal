<h2>Kontak Kami</h2>

<p>Untuk informasi lebih lanjut mengenai produk dan layanan kami, silakan hubungi kami melalui kontak berikut:</p>

<table class="table table-borderless">
  <tbody>
    <tr>
      <th scope="row">🏢 Alamat</th>
      <td>Jl. Mataram No. 45, Yogyakarta 55212, Indonesia</td>
    </tr>
    <tr>
      <th scope="row">📞 Telepon</th>
      <td>(0274) 567890</td>
    </tr>
    <tr>
      <th scope="row">📠 Fax</th>
      <td>(0274) 567891</td>
    </tr>
    <tr>
      <th scope="row">📱 WhatsApp</th>
      <td>+62 812-3456-7890</td>
    </tr>
    <tr>
      <th scope="row">✉️ Email</th>
      <td>info@nusantararasa.co.id</td>
    </tr>
    <tr>
      <th scope="row">🌐 Website</th>
      <td><a href="https://www.nusantararasa.co.id" target="_blank">www.nusantararasa.co.id</a></td>
    </tr>
  </tbody>
</table>

<p>
  Kami dengan senang hati akan membantu kebutuhan Anda seputar produk, pemesanan, kerja sama bisnis, maupun pertanyaan lainnya.
</p>
