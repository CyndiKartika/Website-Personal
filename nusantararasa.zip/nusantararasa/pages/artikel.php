<?php
include 'koneksi.php';

$kategori = isset($_GET['kategori']) ? $_GET['kategori'] : '';
$query = "SELECT * FROM artikel WHERE kategori = '$kategori' ORDER BY id_artikel DESC";
$result = mysqli_query($conn, $query);
?>

<h3>Artikel: <?= htmlspecialchars($kategori); ?></h3>
<div class="row">
  <?php if (mysqli_num_rows($result) > 0): ?>
    <?php while ($row = mysqli_fetch_assoc($result)): ?>
      <div class="col-md-12 mb-4">
        <div class="card">
          <div class="text-center mt-3">
            <img src="gambar_artikel/<?= $row['gambar']; ?>" class="card-img-top w-50" style="object-fit:cover;" alt="Gambar Artikel">
          </div>
          <div class="card-body">
            <h5 class="card-title"><?= $row['judul']; ?></h5>
            <p class="card-text"><?= nl2br($row['isi']); ?></p>
          </div>
        </div>
      </div>
    <?php endwhile; ?>
  <?php else: ?>
    <p>Tidak ada artikel untuk kategori ini.</p>
  <?php endif; ?>
</div>
