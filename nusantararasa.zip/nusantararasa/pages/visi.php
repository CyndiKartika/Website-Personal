<h3>Visi</h3>
<p>
  Menjadi perusahaan kuliner nasional yang menghadirkan kelezatan autentik Nusantara dengan inovasi berkelanjutan dan jangkauan global.
</p>

<h3>Misi</h3>
<ul>
  <li>Menyediakan produk makanan dan minuman khas Indonesia yang autentik, berkualitas tinggi, halal, dan bergizi.</li>
  <li>Melakukan inovasi kreatif dalam pengembangan cita rasa dan varian produk agar selalu relevan dengan preferensi modern.</li>
  <li>Membangun kemitraan dan pemberdayaan UMKM lokal untuk memperkuat ekosistem kuliner Nusantara.</li>
  <li>Memberikan pelayanan prima melalui sistem distribusi yang andal—baik online maupun offline.</li>
  <li>Menerapkan praktik bisnis berkelanjutan yang ramah lingkungan dan mendukung kesejahteraan komunitas.</li>
</ul>
