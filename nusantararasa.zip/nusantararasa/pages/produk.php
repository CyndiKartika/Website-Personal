<h2>Produk dan Layanan Kami</h2>

<p>
  PT. Nusantara Rasa merupakan perusahaan yang bergerak di bidang kuliner dan penyediaan makanan khas Nusantara. Kami menawarkan beragam produk makanan dan minuman yang menggambarkan kekayaan rasa dari berbagai daerah di Indonesia. Tidak hanya itu, kami juga menyediakan layanan katering dan pemesanan untuk berbagai keperluan acara.
</p>

<h3>Produk Kami</h3>
<ul>
  <li><strong>Nasi Box Nusantara:</strong> Paket nasi lengkap dengan lauk tradisional seperti ayam bumbu rujak, rendang, ikan sambal matah, dll.</li>
  <li><strong>Snack Box:</strong> Aneka kue tradisional dan modern yang cocok untuk acara formal maupun santai.</li>
  <li><strong>Roti & Kue Kering:</strong> Produk roti isi, roti manis, hingga kue kering khas lebaran dan pesta.</li>
  <li><strong>Minuman Tradisional:</strong> Seperti wedang uwuh, beras kencur, jahe merah, dan es dawet asli Jawa.</li>
  <li><strong>Produk Kemasan:</strong> Sambal khas Nusantara, keripik tempe, abon, dan camilan oleh-oleh khas daerah.</li>
</ul>

<h3>Layanan Kami</h3>
<ul>
  <li><strong>Layanan Katering:</strong> Untuk acara pernikahan, seminar, pelatihan, gathering, ulang tahun, dan berbagai event lainnya.</li>
  <li><strong>Paket Langganan Makan Siang:</strong> Untuk kantor, sekolah, dan instansi yang membutuhkan layanan makan harian.</li>
  <li><strong>Pemesanan Online & Antar:</strong> Melalui website resmi dan platform pesan-antar makanan, produk kami dapat dinikmati dengan mudah di rumah Anda.</li>
  <li><strong>Kerja Sama Reseller & Kemitraan:</strong> Terbuka untuk mitra usaha yang ingin menjual ulang produk PT. Nusantara Rasa di berbagai daerah.</li>
</ul>

<p>
  Dengan komitmen pada kualitas dan cita rasa, kami terus berinovasi untuk menghadirkan produk-produk terbaik yang mampu memuaskan selera konsumen lokal maupun internasional.
</p>
