<h2>Tentang Kami</h2>

<p>
  <strong>PT. Nusantara Rasa</strong> adalah perusahaan kuliner yang berdiri sejak tahun 2010 di Kota Yogyakarta. Perusahaan ini berawal dari sebuah usaha rumahan yang berkomitmen untuk menghadirkan cita rasa khas Nusantara melalui berbagai produk makanan dan minuman yang berkualitas.
</p>

<p>
  Seiring dengan perkembangan zaman dan meningkatnya permintaan pasar, PT. Nusantara Rasa terus berkembang menjadi perusahaan profesional yang memproduksi dan mendistribusikan aneka kuliner tradisional maupun modern. Fokus utama kami adalah menghadirkan kelezatan khas Indonesia yang autentik dengan sentuhan inovasi agar dapat dinikmati oleh berbagai kalangan, baik lokal maupun mancanegara.
</p>

<p>
  Perusahaan kami bergerak di bidang produksi makanan dan minuman, katering, penyediaan paket nasi box dan snack box untuk acara-acara formal maupun non-formal, serta pemasaran produk kuliner secara online dan offline. Selain itu, kami juga aktif menjalin kerja sama dengan UMKM lokal untuk memperluas jangkauan produk sekaligus mendukung pertumbuhan ekonomi daerah.
</p>

<p>
  Dengan mengusung semangat <em>"Membawa Rasa Nusantara ke Setiap Meja Makan"</em>, kami berkomitmen untuk selalu menjaga kualitas, keaslian rasa, dan kepuasan pelanggan. PT. Nusantara Rasa akan terus berinovasi dalam menciptakan produk kuliner terbaik yang dapat menjadi kebanggaan bangsa.
</p>
