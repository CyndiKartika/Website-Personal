<h3>Pengalaman Perusahaan</h3>
<p>
  PT. Nusantara Rasa telah beroperasi sejak tahun 2010 dan memiliki pengalaman lebih dari satu dekade dalam industri kuliner. Kami telah melayani berbagai kebutuhan pelanggan, mulai dari individu, perusahaan, hingga instansi pemerintahan. Berbekal pengalaman panjang tersebut, kami memahami dengan baik selera pasar, tren kuliner, serta standar kualitas yang dibutuhkan untuk bersaing di era modern.
</p>

<p>
  Sepanjang perjalanan kami, PT. Nusantara Rasa telah dipercaya untuk menyediakan layanan katering acara resmi, pernikahan, seminar, hingga penyediaan makanan harian untuk berbagai perusahaan dan sekolah. Pengalaman ini menjadi modal utama kami untuk terus tumbuh dan memberikan pelayanan terbaik.
</p>

<h3>Kelebihan Perusahaan</h3>
<ul>
  <li><strong>Rasa Autentik Nusantara:</strong> Produk kami mengangkat cita rasa khas Indonesia yang sulit ditemukan di tempat lain.</li>
  <li><strong>Bahan Berkualitas:</strong> Kami hanya menggunakan bahan segar, alami, dan halal dalam setiap proses produksi.</li>
  <li><strong>Inovatif dan Fleksibel:</strong> Mampu menyesuaikan menu dengan kebutuhan pelanggan tanpa mengurangi kualitas rasa.</li>
  <li><strong>Dukungan Tim Profesional:</strong> Tim kami terdiri dari tenaga ahli di bidang kuliner dan pelayanan.</li>
  <li><strong>Distribusi Luas:</strong> Melayani pemesanan secara langsung, online, dan menjangkau hingga luar daerah melalui mitra logistik.</li>
  <li><strong>Kepuasan Pelanggan:</strong> Kami menjadikan kepuasan pelanggan sebagai prioritas utama melalui pelayanan ramah dan cepat tanggap.</li>
</ul>
