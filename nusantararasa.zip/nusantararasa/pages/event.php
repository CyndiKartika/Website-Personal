<div class="container py-5">
  <h2 class="text-center mb-4">Event Perusahaan</h2>
  <p class="text-center mb-4">Berikut adalah beberapa kegiatan dan event yang telah diselenggarakan oleh PT. Nusantara Rasa.</p>

  <div class="row justify-content-center text-center g-4">
    <!-- Event dengan gambar -->
    <div class="col-12 col-sm-6 col-md-4">
      <img src="images/event1.jpg" alt="Pelatihan UMKM" style="width: 100%; max-height: 200px; object-fit: cover;" class="rounded shadow-sm">
      <h5 class="mt-3">Pelatihan UMKM</h5>
      <p class="small">Meningkatkan kapasitas pelaku UMKM di bidang pengolahan makanan tradisional.</p>
    </div>
    <div class="col-12 col-sm-6 col-md-4">
      <img src="images/event2.jpg" alt="Festival Kuliner Nusantara" style="width: 100%; max-height: 200px; object-fit: cover;" class="rounded shadow-sm">
      <h5 class="mt-3">Festival Kuliner Nusantara</h5>
      <p class="small">Ajang promosi makanan khas daerah kepada masyarakat luas.</p>
    </div>
    <div class="col-12 col-sm-6 col-md-4">
      <img src="images/event3.jpg" alt="Festival Kuliner Nusantara" style="width: 100%; max-height: 200px; object-fit: cover;" class="rounded shadow-sm">
      <h5 class="mt-3">Webinar Inovasi Rasa Nusantara</h5>
      <p class="small">Webinar ini membahas bagaimana inovasi teknologi dapat mengangkat cita rasa kuliner khas Nusantara ke level yang lebih tinggi.</p>
    </div>

    <!-- Event hanya teks -->
    <div class="col-12 col-sm-6 col-md-4">
      <div class="border p-4 rounded bg-light h-100">
        <h5>Webinar Inovasi Rasa</h5>
        <p class="small">Diskusi daring bersama ahli kuliner membahas tren dan inovasi pangan.</p>
      </div>
    </div>
    <div class="col-12 col-sm-6 col-md-4">
      <div class="border p-4 rounded bg-light h-100">
        <h5>Workshop Packaging</h5>
        <p class="small">Pelatihan pengemasan produk agar menarik dan memenuhi standar ekspor.</p>
      </div>
    </div>
  </div>
</div>
