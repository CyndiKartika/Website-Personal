<h2 class="mb-4">Galeri Kegiatan Perusahaan</h2>
<div class="row row-cols-1 row-cols-md-3 g-4">
  <!-- Item Galeri -->
  <div class="col">
    <div class="card h-100">
      <img src="images/galeri1.jpg" class="card-img-top gallery-img" alt="Pelatihan SDM">
      <div class="card-body text-center">
        <p class="card-text">Pelatihan SDM</p>
      </div>
    </div>
  </div>

  <div class="col">
    <div class="card h-100">
      <img src="images/galeri2.jpg" class="card-img-top gallery-img" alt="Pameran Kuliner">
      <div class="card-body text-center">
        <p class="card-text">Pameran Kuliner</p>
      </div>
    </div>
  </div>

  <div class="col">
    <div class="card h-100">
      <img src="images/galeri3.jpg" class="card-img-top gallery-img" alt="Pameran Produk">
      <div class="card-body text-center">
        <p class="card-text">Pameran Produk</p>
      </div>
    </div>
  </div>

  <div class="col">
    <div class="card h-100">
      <img src="images/galeri4.jpg" class="card-img-top gallery-img" alt="Kegiatan CSR">
      <div class="card-body text-center">
        <p class="card-text">Kegiatan CSR</p>
      </div>
    </div>
  </div>

  <div class="col">
    <div class="card h-100">
      <img src="images/galeri5.jpg" class="card-img-top gallery-img" alt="Pelatihan Karyawan">
      <div class="card-body text-center">
        <p class="card-text">Pelatihan Karyawan</p>
      </div>
    </div>
  </div>

  <div class="col">
    <div class="card h-100">
      <img src="images/galeri6.jpg" class="card-img-top gallery-img" alt="Kegiatan Sosial">
      <div class="card-body text-center">
        <p class="card-text">Kegiatan Sosial</p>
      </div>
    </div>
  </div>
</div>
