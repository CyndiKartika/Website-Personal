<div class="container py-5">
  <h2 class="text-center mb-4">Klien Kami</h2>
  <p class="text-center mb-4">Berikut adalah beberapa klien/perusahaan yang telah mempercayai layanan kami.</p>

  <div class="row justify-content-center text-center g-4">
    <!-- Klien dengan logo -->
    <div class="col-6 col-sm-4 col-md-3">
      <img src="images/logo1.jpg" alt="PT. Nusantara Sejahtera" style="width: 100%; max-height: 100px; object-fit: contain;">
      <p class="mt-2">PT. Nusantara Sejahtera</p>
    </div>
    <div class="col-6 col-sm-4 col-md-3">
      <img src="images/logo2.jpg" alt="CV. Maju Jaya" style="width: 100%; max-height: 100px; object-fit: contain;">
      <p class="mt-2">CV. Maju Jaya</p>
    </div>

    <!-- Klien hanya nama (tanpa logo) -->
    <div class="col-6 col-sm-4 col-md-3">
      <div class="border p-4 rounded bg-light h-100 d-flex align-items-center justify-content-center">
        <p class="mb-0">PT. Sumber Rezeki</p>
      </div>
    </div>
    <div class="col-6 col-sm-4 col-md-3">
      <div class="border p-4 rounded bg-light h-100 d-flex align-items-center justify-content-center">
        <p class="mb-0">CV. Berkah Alam</p>
      </div>
    </div>
  </div>
</div>
